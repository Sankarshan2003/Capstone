import serial
import time

class BarcodeReader:
    
    def __init__(self,port):
        self.barcodeScanner = serial.Serial(port=port, baudrate=9600, timeout=0.1)
        # self.timeout = timeout
        
    def readBarcode(self,timeout):
        self.start_time = time.time()
        self.timeout = timeout
        self.barcodeScanner.flushInput()
        self.barcode_data = ""
        ret = False
        while not self.barcode_data and not (time.time() - self.start_time) >= self.timeout:
            self.barcode_data = self.barcodeScanner.readline().decode('utf-8').strip()
        
        if self.barcode_data != "":
            ret = True
        
        return ret, self.barcode_data
    
    
